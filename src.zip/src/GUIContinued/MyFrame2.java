package GUIContinued;

public class MyFrame2 {
}
