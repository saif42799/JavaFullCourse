package Inheritance;

public class Bicycle extends Vehicle {

    int whels = 2;
    int pedels = 2;

}
