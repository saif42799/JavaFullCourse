package Inheritance;

public class Vehicle {

    //attributes
    double speed;

    //methods
    void go(){
        System.out.println("This vehicle is moving");
    }

    void stop(){
        System.out.println("This vehicle is stopped");
    }




}
