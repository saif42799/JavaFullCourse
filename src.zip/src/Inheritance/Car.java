package Inheritance;

public class Car extends Vehicle {

    int whells = 4;
    int doors = 4;

}
