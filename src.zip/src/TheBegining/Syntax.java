package TheBegining;

public class Syntax {

    // Text Book 1: http://itec2140.gitlab.io/
    // Text Book 2: http://itec2150.gitlab.io/




    //This  section goes over this YouTube video - https://www.youtube.com/watch?v=eIrMbAQSU34&list=WL&index=275&t=344s


    //Funtion  =








}
