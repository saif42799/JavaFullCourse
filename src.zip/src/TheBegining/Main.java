package TheBegining;

public class Main {
    public static void main(String[] args) {
    // ^ main method

        System.out.println("\\Hello");
    }
}
