package AccessModifers;

public class Wah {
}
