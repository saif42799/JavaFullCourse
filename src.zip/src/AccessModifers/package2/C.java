package AccessModifers.package2;
import AccessModifers.package1.*;

public class C {

    String noModDefaluMessage = "This has no access modifier(default)";

    public String publicMessage = "This is Public";

    protected String protectMessage = "This is protected";

    private String privateMessage = "This is private";

}
