package AccessModifers.package1;
import AccessModifers.package2.*;

public class B {

    private String privateMessage = "This is private";


}
