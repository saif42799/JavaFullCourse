package Methods;

public class method {
    public static void main(String[] args) {

        String name = "Bro";
        int age = 21;
        hello(name, age);

    }

    static void hello(String tile, int youth){
        System.out.println("Hello" + tile);
        System.out.println("You are " + youth + " Years old");
    }


}
