package Methods;

public class ReturnTypes {
    public static void main(String[] args) {

        int x = 3;
        int y = 4;

        System.out.println(add(x,y));
    }

    static int add(int x, int y){
        int z = x + y;
        return z;
    }


}
