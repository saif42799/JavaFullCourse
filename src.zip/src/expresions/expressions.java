package expresions;

public class expressions {
    public static void main(String[] args) {

        int friends = 10;

        friends = friends + 1; // or frinds++
        System.out.println(friends);

        double frinds2 = 11;
        frinds2 = (double) frinds2 / 3;
        System.out.println(frinds2);

    }
}
