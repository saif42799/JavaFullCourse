package MathClass;

public class mathMethods {
    public static void main(String[] args) {

        double x = 3.14;
        double y = -10;

        double z = Math.max(x, y);
        double l = Math.min(x,y);
        double k = Math.abs(y);
        double j = Math.sqrt(x);

        System.out.println(z);
        System.out.println(l);
        System.out.println(k);
        System.out.println(j);


    }
}
