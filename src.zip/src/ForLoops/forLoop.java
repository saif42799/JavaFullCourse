package ForLoops;

public class forLoop {
    public static void main(String[] args) {

        for (int i = 10; i >= 0; i--){
            System.out.println(i);
        }
        System.out.println("Happy new year!" + "\n");


        for (int i = 0; i <= 10; i++){
            System.out.println(i);
        }
        System.out.println("\n");


        for (int i = 10; i >= 0; i-=2){
            System.out.println(i);
        }
        System.out.println("Happy new year!");
    }
}
