package Abstract;

public class Main {
    public static void main(String[] args) {

//        Vehicle vehicle = new Vehicle();
        Car car = new Car();
        car.go();

    }
}
