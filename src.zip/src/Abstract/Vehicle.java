package Abstract;

public abstract class Vehicle {

    //abstract method
    abstract void go();
}
