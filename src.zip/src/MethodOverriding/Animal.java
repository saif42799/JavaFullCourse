package MethodOverriding;

public class Animal {


    //method
     void speak(){
        System.out.println("The animal speaks");
    }
}
