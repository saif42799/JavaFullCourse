package ObjectPassing;

public class Garage {

    //method
    //void doesnt return anything

    void park(Car car){
        System.out.println("The " + car.name + " is parked in the garage.");
    }
}
