package ObjectPassing;

public class Car {

    //attributte
    String name;

    //constructor
    Car(String name){
        this.name = name;
    }
}
