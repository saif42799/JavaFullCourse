package ArrayOfObjects;

public class Food {

    String name;
    int number;
    char ch;

    Food(String name){
        this.name = name;
    }

    Food(int number){
        this.number = number;

    }

    Food(char ch){
        this.ch = ch;
    }
}
