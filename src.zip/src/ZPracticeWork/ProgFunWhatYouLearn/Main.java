package ZPracticeWork.ProgFunWhatYouLearn;

public class Main {
    public static void main(String[] args) {




    }
}
