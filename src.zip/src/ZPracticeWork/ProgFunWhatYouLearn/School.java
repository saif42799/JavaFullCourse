package ZPracticeWork.ProgFunWhatYouLearn;

public class School {
}
