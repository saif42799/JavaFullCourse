package WhileLoops;

public class doWhileLoop {
    public static void main(String[] args) {

        int i = 1;
        do {
            System.out.println("Hello " + i);
            i++;
        }
        while (i <= 3);



        int a = 0;
        do {
            System.out.println("a");
        }
        while (a == 3);



        int b = 1;
        do {
            System.out.println("Number: " + b);
            b++;
        }
        while (b <= 15);

    }
}
