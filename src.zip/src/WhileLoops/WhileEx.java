package WhileLoops;

public class WhileEx {
    public static void main(String[] args) {



        int employees = 1000;
        while (employees != 0){
            System.out.println("Have a good vacation!");
            employees--;
        }


        int i = 3;
        while (i > 0){
            System.out.println(i);
            i--;
        }

    }
}
