package Swiches;

public class simpleSwitch {
    public static void main(String[] args) {

        int x = 1;

        switch (x){
            case 1:
                System.out.println("1 Blah");
                break;
            case 2:
                System.out.println("2 Blah");
                break;
            default:
                System.out.println("Not  a choice");
        }

    }
}
