package ForEachLoop;

public class forEachLoop {
    public static void main(String[] args) {

        String[] animals = {"cat", "dog", "rat", "bird"};

        for (String i : animals){
            System.out.println(i);

        }


    }
}
