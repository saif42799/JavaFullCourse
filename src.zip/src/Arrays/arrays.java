package Arrays;

import java.util.ArrayList;
import java.util.Arrays;

public class arrays {
    public static void main(String[] args) {


        String[] cars = {"Camero", "Corvette", "Tesla", "BMW"};

         cars[0] = "Mustand";

        System.out.println(cars[0]);
        System.out.println(Arrays.toString(cars));





    }
}
