package LocalGlobalVariables;

public class Main {
    public static void main(String[] args) {

        DiceRoller diceRoller = new DiceRoller();

        DiceRollerGLobal diceRollerGLobal = new DiceRollerGLobal();


    }
}
