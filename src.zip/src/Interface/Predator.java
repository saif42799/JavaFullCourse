package Interface;

public interface Predator {
    void hunt();

}
