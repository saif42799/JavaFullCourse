package Interface;

public interface Prey {

    void flee();

}
