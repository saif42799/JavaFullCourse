package PolymorphismDyn;

public class Vehicle {

    public void go() {

    }

}
