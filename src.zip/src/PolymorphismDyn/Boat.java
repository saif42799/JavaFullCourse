package PolymorphismDyn;

public class Boat extends Vehicle{

    @Override
    public void go(){
        System.out.println("The boat begins moving");
    }
}
