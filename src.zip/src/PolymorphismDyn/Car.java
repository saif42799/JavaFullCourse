package PolymorphismDyn;

public class Car extends Vehicle{

    @Override
    public void go(){
        System.out.println("The car begins moving");
    }

}
