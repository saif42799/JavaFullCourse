package PolymorphismDyn.DynamicPolymorphism;

public class Cat extends Animal{

    @Override
    public void speak(){
        System.out.println("Cat goes *meow*");
    }

}
