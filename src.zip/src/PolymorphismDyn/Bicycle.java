package PolymorphismDyn;

public class Bicycle extends Vehicle {

    @Override
    public void go(){
        System.out.println("The bicycle begins moving");
    }

}
