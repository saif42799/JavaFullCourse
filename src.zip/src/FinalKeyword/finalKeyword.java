package FinalKeyword;

public class finalKeyword {
    public static void main(String[] args) {

        final double pi = 3.14159;

//        pi = 4;

        System.out.println(pi);

    }
}
