package StaticKeyword;

public class Main {
    public static void main(String[] args) {

        Friends friends1 = new Friends("Spongebob");
        Friends friends2 = new Friends("Patrick");
        Friends friends3 = new Friends("Squidward");
        Friends friends4 = new Friends("Sandy");

//        System.out.println(Friends.numberOfFriends);

        Friends.dispaly();

    }
}
