package WrapperClasses;

public class Wrapperclass {
    public static void main(String[] args) {


        Boolean a = true;
        Character b = '@';
        Integer c = 123;
        Double d = 3.14;
        String e = "Bro";



    }
}
